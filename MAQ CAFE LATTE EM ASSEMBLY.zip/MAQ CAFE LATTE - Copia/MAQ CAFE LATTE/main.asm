#define __SFR_OFFSET 0   
#define TTORRA  r1
#define TMOAR r2
#define  TESQUENTAR  r22
#define  TINFUSAO  r23
#define  TDESPEJAR  r12
#define  TBATER  r20
#define  mais PC0
#define  menos PC1
#define  enter  PC2
#define stop  PC3
#define aux r16
#define timer r24
#define auxstop r5
#define TORRADOR PB4
#define MOEDOR PB5
#define PRONTO PB6
.ORG 0x000
rjmp main
.ORG 0x001A
    rjmp TIM1_OVERFLOW      ; Timer 1 Overflow Interrupt


    
#include "biblioteca.h"



; Interrup��o Timer1 (1 segundo) - Cria��o de atraso em segundos
TIM1_OVERFLOW:
      ; Atualiza o valor de contagem inicial do Timer1
    ldi r16, 0xC2
    sts TCNT1H, r16
    ldi r16, 0xF6
    sts TCNT1L, r16
    ldi r16,0

    ; Decrementa o contador de atraso_s se for maior que zero
    tst timer
    breq fim_timer           ; Se atraso_s j� � zero, n�o faz nada
    dec timer 
	 
	ldi aux, 50
	tst valor_PWM
	breq fim_timer
	sub valor_PWM, aux  
	rcall escreve_pwm     
    reti
fim_timer:
    reti                 ; Retorna da interrup��o
    

main:
  ldi aux, 0b11111111 
	out DDRB, aux 
	ldi aux, 0b00000000
	out PORTB, aux  
	out DDRC, aux  
	ldi aux, 0b11111111
	out DDRD, aux  
	ldi aux, 0b11111111
	out PORTC, aux
 	rcall lcd_init 	
	rcall lcd_clear 
	rcall set_pwm_pb3
	rcall set_timer1
	rcall  usart_init ; configura a comunicacao serial em 9600 bps
	sei
	
	cbi PORTB, 4
	cbi PORTB, 5
	cbi PORTB, 6
	ldi aux, 0
	mov TTORRA, aux
	mov TMOAR, aux
	mov TESQUENTAR, aux 
	mov TINFUSAO, aux
	mov TDESPEJAR, aux
	mov TBATER, aux

Comeco: 
	cbi PORTB, 4
	cbi PORTB, 5
	cbi PORTB, 6
	rcall desliga_pwm_pb3
	rcall set_pwm_pb3
	ldi aux, 0
	mov TTORRA, aux
	mov TMOAR, aux
	mov TESQUENTAR, aux 
	mov TINFUSAO, aux
	mov TDESPEJAR, aux
	mov TBATER, aux

	ldi lcd_col, 7  
	rcall lcd_lin0_col  
	ldi lcd_caracter,'O' 
	rcall lcd_write_caracter 
	ldi lcd_caracter,'L'
	rcall lcd_write_caracter
	ldi lcd_caracter,'A'
	rcall lcd_write_caracter
	ldi lcd_caracter,'!'
	rcall lcd_write_caracter
	ldi delay_time, 1
	rcall delay_seconds
	ldi delay_time, 3
	rcall delay_seconds

	
	ldi transmit_caracter,10
	rcall usart_transmit
	ldi transmit_caracter,13
	rcall usart_transmit
	ldi transmit_caracter,'O'	; carrega o caracter
	rcall usart_transmit	;transmite o caracter	
	ldi transmit_caracter,'L'
	rcall usart_transmit
	ldi transmit_caracter,'A'
	rcall usart_transmit
	
	ldi transmit_caracter,10
	rcall usart_transmit
	ldi transmit_caracter,13
	rcall usart_transmit
	ldi transmit_caracter,10
	rcall usart_transmit
	ldi transmit_caracter,13
	rcall usart_transmit
	ldi transmit_caracter,10
	rcall usart_transmit
	ldi transmit_caracter,13
	rcall usart_transmit

	
	
Def_TTORRAR:
	rcall lcd_clear
	ldi lcd_col, 0
	rcall lcd_lin0_col
	ldi lcd_caracter, 'T'
	rcall lcd_write_caracter
	ldi lcd_caracter, 'E'
	rcall lcd_write_caracter
	ldi lcd_caracter, 'M'
	rcall lcd_write_caracter
	ldi lcd_caracter, 'P'
	rcall lcd_write_caracter
	ldi lcd_caracter, 'O'
	rcall lcd_write_caracter
	ldi lcd_caracter, ' '
	rcall lcd_write_caracter
	ldi lcd_caracter, 'T'
	rcall lcd_write_caracter
	ldi lcd_caracter, 'O'
	rcall lcd_write_caracter
	ldi lcd_caracter, 'R'
	rcall lcd_write_caracter
	ldi lcd_caracter, 'R'
	rcall lcd_write_caracter
	ldi lcd_caracter, 'A'
	rcall lcd_write_caracter
	ldi lcd_caracter, 'R'
	rcall lcd_write_caracter
	ldi lcd_caracter, ' '
	rcall lcd_write_caracter

	ldi transmit_caracter,10
	rcall usart_transmit
	ldi transmit_caracter,13
	rcall usart_transmit
	ldi transmit_caracter,'T'	; carrega o caracter
	rcall usart_transmit	;transmite o caracter	
	ldi transmit_caracter,'E'
	rcall usart_transmit
	ldi transmit_caracter,'M'
	rcall usart_transmit
	ldi transmit_caracter,'P'
	rcall usart_transmit
	ldi transmit_caracter,'O'
	rcall usart_transmit
	ldi transmit_caracter,' '
	rcall usart_transmit
	ldi transmit_caracter,'T'
	rcall usart_transmit
	ldi transmit_caracter,'O'
	rcall usart_transmit
	ldi transmit_caracter,'R'
	rcall usart_transmit
	ldi transmit_caracter,'R'
	rcall usart_transmit
	ldi transmit_caracter,'A'
	rcall usart_transmit
	
	ldi transmit_caracter,10
	rcall usart_transmit
	ldi transmit_caracter,13
	rcall usart_transmit
	ldi transmit_caracter,10
	rcall usart_transmit
	ldi transmit_caracter,13
	rcall usart_transmit
	ldi transmit_caracter,10
	rcall usart_transmit
	ldi transmit_caracter,13
	rcall usart_transmit

	sbis PINC, 3
	rjmp EMERGENCIA
	
Imp_TTORRA:
	ldi lcd_col,8  
	rcall lcd_lin1_col  
	mov lcd_number, TTORRA 
	rcall lcd_write_number

	sbis PINC, 3
	rjmp EMERGENCIA

	sbis PINC, 0 
	rjmp Aum_TTORRA 

	sbis PINC, 1 
	rjmp Dim_TTORRA  
	
	sbis PINC, 2 
	rjmp Def_TMOAGEM 
	rjmp Imp_TTORRA

	
	


Aum_TTORRA:
	ldi aux,100				
	eor aux,TTORRA	
	breq Imp_TTORRA
	inc TTORRA
	ldi delay_time,200
	rcall delay_miliseconds
	rjmp Imp_TTORRA

Dim_TTORRA:
		ldi aux,0 		
	eor aux,TTORRA	
	breq Imp_TTORRA
	dec TTORRA
	ldi delay_time,200
	rcall delay_miliseconds 
	rjmp Imp_TTORRA

Def_TMOAGEM:
	rcall mensagem_TMOAR
		ldi transmit_caracter,10
	rcall usart_transmit
	ldi transmit_caracter,13
	rcall usart_transmit
	ldi transmit_caracter,'T'	; carrega o caracter
	rcall usart_transmit	;transmite o caracter	
	ldi transmit_caracter,'E'
	rcall usart_transmit
	ldi transmit_caracter,'M'
	rcall usart_transmit
	ldi transmit_caracter,'P'
	rcall usart_transmit
	ldi transmit_caracter,'O'
	rcall usart_transmit
	ldi transmit_caracter,' '
	rcall usart_transmit
	ldi transmit_caracter,'M'
	rcall usart_transmit
	ldi transmit_caracter,'O'
	rcall usart_transmit
	ldi transmit_caracter,'A'
	rcall usart_transmit
	ldi transmit_caracter,'G'
	rcall usart_transmit
	ldi transmit_caracter,'E'
	rcall usart_transmit
	ldi transmit_caracter,'M'
	rcall usart_transmit
	ldi transmit_caracter,10
	rcall usart_transmit
	ldi transmit_caracter,13
	rcall usart_transmit
	ldi transmit_caracter,10
	rcall usart_transmit
	ldi transmit_caracter,13
	rcall usart_transmit
	ldi transmit_caracter,10
	rcall usart_transmit
	ldi transmit_caracter,13
	rcall usart_transmit
	
		ldi delay_time,200
	rcall delay_miliseconds 

Imp_TMOAR:
	ldi lcd_col,8  
	rcall lcd_lin1_col  
	
	mov lcd_number, TMOAR 
	rcall lcd_write_number
	sbis PINC, 0
	rjmp Aum_TMOAR 

	sbis PINC, 3
	rjmp EMERGENCIA
	
	sbis PINC, 1 
	rjmp Dim_TMOAR 

	sbis PINC, 2 
	rjmp Def_TESQUENTAR
	rjmp Imp_TMOAR
Aum_TMOAR:
	ldi aux,100 		
	eor aux,TMOAR		
	breq Imp_TMOAR
	inc TMOAR
	ldi delay_time,200
	rcall delay_miliseconds 
	rjmp Imp_TMOAR

Dim_TMOAR:
	ldi aux,0 		
	eor aux,TMOAR		
	breq Imp_TMOAR
	dec TMOAR
	ldi delay_time,200  
	rcall delay_miliseconds 
	rjmp Imp_TMOAR

Def_TESQUENTAR:
  rcall mensagem_TESQUENTAR
  ldi transmit_caracter,10
	rcall usart_transmit
	ldi transmit_caracter,13
	rcall usart_transmit
	ldi transmit_caracter,'T'	; carrega o caracter
	rcall usart_transmit	;transmite o caracter	
	ldi transmit_caracter,'E'
	rcall usart_transmit
	ldi transmit_caracter,'M'
	rcall usart_transmit
	ldi transmit_caracter,'P'
	rcall usart_transmit
	ldi transmit_caracter,'O'
	rcall usart_transmit
	ldi transmit_caracter,' '
	rcall usart_transmit
	ldi transmit_caracter,'E'
	rcall usart_transmit
	ldi transmit_caracter,'S'
	rcall usart_transmit
	ldi transmit_caracter,'Q'
	rcall usart_transmit
	ldi transmit_caracter,'U'
	rcall usart_transmit
	ldi transmit_caracter,'E'
	rcall usart_transmit
	ldi transmit_caracter,'N'
	rcall usart_transmit
	ldi transmit_caracter,'T'
	rcall usart_transmit
	ldi transmit_caracter,'A'
	rcall usart_transmit
	ldi transmit_caracter,'R'
	rcall usart_transmit
	ldi transmit_caracter,10
	rcall usart_transmit
	ldi transmit_caracter,13
	rcall usart_transmit
	ldi transmit_caracter,10
	rcall usart_transmit
	ldi transmit_caracter,13
	rcall usart_transmit
	ldi transmit_caracter,10
	rcall usart_transmit
	ldi transmit_caracter,13
	rcall usart_transmit
	
	ldi delay_time,200
	rcall delay_miliseconds 


Imp_TESQUENTAR:
	ldi lcd_col,8  
	rcall lcd_lin1_col  
	mov lcd_number, TESQUENTAR 
	rcall lcd_write_number

	sbis PINC, 3
	rjmp EMERGENCIA

	sbis PINC, 0 
	rjmp Aum_TESQUENTAR 
	
	sbis PINC, 1 
	rjmp Dim_TESQUENTAR 
	
	sbis PINC, 2 
	rjmp Def_TINFUSAO 
	rjmp Imp_TESQUENTAR
	
	Aum_TESQUENTAR:
	ldi aux,100 		
	eor aux,TESQUENTAR			
	breq Imp_TESQUENTAR
	inc TESQUENTAR
	ldi delay_time,200 
	rcall delay_miliseconds 
	rjmp Imp_TESQUENTAR

Dim_TESQUENTAR:
	ldi aux,0				
	eor aux,TESQUENTAR		
	breq Imp_TESQUENTAR
	dec TESQUENTAR
	ldi delay_time,200
	rcall delay_miliseconds 
	rjmp Imp_TESQUENTAR

	Def_TINFUSAO:
  rcall mensagem_TINFUSAO
  ldi transmit_caracter,10
	rcall usart_transmit
	ldi transmit_caracter,13
	rcall usart_transmit
	ldi transmit_caracter,'T'	; carrega o caracter
	rcall usart_transmit	;transmite o caracter	
	ldi transmit_caracter,'E'
	rcall usart_transmit
	ldi transmit_caracter,'M'
	rcall usart_transmit
	ldi transmit_caracter,'P'
	rcall usart_transmit
	ldi transmit_caracter,'O'
	rcall usart_transmit
	ldi transmit_caracter,' '
	rcall usart_transmit
	ldi transmit_caracter,'I'
	rcall usart_transmit
	ldi transmit_caracter,'N'
	rcall usart_transmit
	ldi transmit_caracter,'F'
	rcall usart_transmit
	ldi transmit_caracter,'U'
	rcall usart_transmit
	ldi transmit_caracter,'S'
	rcall usart_transmit
	ldi transmit_caracter,'A'
	rcall usart_transmit
	ldi transmit_caracter,'O'
	rcall usart_transmit
	ldi transmit_caracter,10
	rcall usart_transmit
	ldi transmit_caracter,13
	rcall usart_transmit
	ldi transmit_caracter,10
	rcall usart_transmit
	ldi transmit_caracter,13
	rcall usart_transmit
	ldi transmit_caracter,10
	rcall usart_transmit
	ldi transmit_caracter,13
	rcall usart_transmit

	ldi delay_time,200
	rcall delay_miliseconds 

	Imp_TINFUSAO:
	ldi lcd_col,8  
	rcall lcd_lin1_col  
	mov lcd_number, TINFUSAO 
	rcall lcd_write_number

	sbis PINC, 3
	rjmp EMERGENCIA

	sbis PINC, 0 
	rjmp Aum_TINFUSAO 
	
	sbis PINC, 1 
	rjmp Dim_TINFUSAO 
	
	sbis PINC, 2 
	rjmp Def_TDESPEJAR
	rjmp Imp_TINFUSAO 
	
	

Aum_TINFUSAO:
	ldi aux,100 			
	eor aux,TINFUSAO			
	breq Imp_TINFUSAO
	inc TINFUSAO
	ldi delay_time,200
	rcall delay_miliseconds  
	rjmp Imp_TINFUSAO

Dim_TINFUSAO:
	ldi aux,0 			
	eor aux,TINFUSAO			
	breq Imp_TINFUSAO
	dec TINFUSAO	
	ldi delay_time,200
	rcall delay_miliseconds 
	rjmp Imp_TINFUSAO

	Def_TDESPEJAR:
  rcall mensagem_TDESPEJAR
  ldi transmit_caracter,10
	rcall usart_transmit
	ldi transmit_caracter,13
	rcall usart_transmit
	ldi transmit_caracter,'T'	; carrega o caracter
	rcall usart_transmit	;transmite o caracter	
	ldi transmit_caracter,'E'
	rcall usart_transmit
	ldi transmit_caracter,'M'
	rcall usart_transmit
	ldi transmit_caracter,'P'
	rcall usart_transmit
	ldi transmit_caracter,'O'
	rcall usart_transmit
	ldi transmit_caracter,' '
	rcall usart_transmit
	ldi transmit_caracter,'D'
	rcall usart_transmit
	ldi transmit_caracter,'E'
	rcall usart_transmit
	ldi transmit_caracter,'S'
	rcall usart_transmit
	ldi transmit_caracter,'P'
	rcall usart_transmit
	ldi transmit_caracter,'E'
	rcall usart_transmit
	ldi transmit_caracter,'J'
	rcall usart_transmit
	ldi transmit_caracter,'A'
	rcall usart_transmit
	ldi transmit_caracter,'R'
	rcall usart_transmit
	ldi transmit_caracter,10
	rcall usart_transmit
	ldi transmit_caracter,13
	rcall usart_transmit
	ldi transmit_caracter,10
	rcall usart_transmit
	ldi transmit_caracter,13
	rcall usart_transmit
	ldi transmit_caracter,10
	rcall usart_transmit
	ldi transmit_caracter,13
	rcall usart_transmit
	ldi delay_time,200
	rcall delay_miliseconds 

	Imp_TDESPEJAR:
	ldi lcd_col,8  
	rcall lcd_lin1_col  
	mov lcd_number, TDESPEJAR 
	rcall lcd_write_number

	sbis PINC, 3
	rjmp EMERGENCIA

	sbis PINC, 0 
	rjmp Aum_TDESPEJAR 

	sbis PINC, 1 
	rjmp Dim_TDESPEJAR 
	
	sbis PINC, 2 
	rjmp Def_TBATER 
	rjmp 	Imp_TDESPEJAR

	

Aum_TDESPEJAR:
	ldi aux,100 	
	eor aux,TDESPEJAR		
	breq Imp_TDESPEJAR
	inc TDESPEJAR
	ldi delay_time,100 
	rcall delay_miliseconds  
	rjmp Imp_TDESPEJAR

Dim_TDESPEJAR:
	ldi aux,0 			
	eor aux,TDESPEJAR			
	breq Imp_TDESPEJAR
	dec TDESPEJAR	
	ldi delay_time,100 
	rcall delay_miliseconds  
	rjmp Imp_TDESPEJAR

	Def_TBATER:
  rcall mensagem_TBATER
  ldi transmit_caracter,10
	rcall usart_transmit
	ldi transmit_caracter,13
	rcall usart_transmit
	ldi transmit_caracter,'T'	; carrega o caracter
	rcall usart_transmit	;transmite o caracter	
	ldi transmit_caracter,'E'
	rcall usart_transmit
	ldi transmit_caracter,'M'
	rcall usart_transmit
	ldi transmit_caracter,'P'
	rcall usart_transmit
	ldi transmit_caracter,'O'
	rcall usart_transmit
	ldi transmit_caracter,' '
	rcall usart_transmit
	ldi transmit_caracter,'B'
	rcall usart_transmit
	ldi transmit_caracter,'A'
	rcall usart_transmit
	ldi transmit_caracter,'T'
	rcall usart_transmit
	ldi transmit_caracter,'E'
	rcall usart_transmit
	ldi transmit_caracter,'R'
	rcall usart_transmit
	ldi transmit_caracter,' '
	rcall usart_transmit
	ldi transmit_caracter,'L'
	rcall usart_transmit
	ldi transmit_caracter,'E'
	rcall usart_transmit
	ldi transmit_caracter,'I'
	rcall usart_transmit
	ldi transmit_caracter,'T'
	rcall usart_transmit
	ldi transmit_caracter,'E'
	rcall usart_transmit
	ldi transmit_caracter,10
	rcall usart_transmit
	ldi transmit_caracter,13
	rcall usart_transmit
	ldi transmit_caracter,10
	rcall usart_transmit
	ldi transmit_caracter,13
	rcall usart_transmit
	ldi transmit_caracter,10
	rcall usart_transmit
	ldi transmit_caracter,13
	rcall usart_transmit
	ldi delay_time,200
	rcall delay_miliseconds 

	Imp_TBATER:
	ldi lcd_col,8  
	rcall lcd_lin1_col  
	mov lcd_number, TBATER 
	rcall lcd_write_number

	sbis PINC, 3
	rjmp EMERGENCIA

	sbis PINC, 0 
	rjmp Aum_TBATER 
	
	sbis PINC, 1 
	rjmp Dim_TBATER 
	
	sbis PINC, 2
	rjmp EM_OPERACAO
	rjmp Imp_TBATER


	

Aum_TBATER:
	ldi aux,100 	
	eor aux,TBATER			
	breq Imp_TBATER
	inc TBATER
	ldi delay_time,100 
	rcall delay_miliseconds 
	rjmp Imp_TBATER

Dim_TBATER:
	ldi aux,0 		
	eor aux,TBATER				
	breq Imp_TBATER
	dec TBATER	
	ldi delay_time,100 
	rcall delay_miliseconds 
	rjmp Imp_TBATER





	
EM_OPERACAO:
	rcall lcd_clear
	ldi lcd_col, 0
	rcall lcd_lin0_col
	ldi lcd_caracter, 'E'
	rcall lcd_write_caracter
	ldi lcd_caracter, 'M'
	rcall lcd_write_caracter
	ldi lcd_caracter, ' '
	rcall lcd_write_caracter
	ldi lcd_caracter, 'O'
	rcall lcd_write_caracter
	ldi lcd_caracter, 'P'
	rcall lcd_write_caracter
	ldi lcd_caracter, 'E'
	rcall lcd_write_caracter
	ldi lcd_caracter, 'R'
	rcall lcd_write_caracter
	ldi lcd_caracter, 'A'
	rcall lcd_write_caracter
	ldi lcd_caracter, 'C'
	rcall lcd_write_caracter
	ldi lcd_caracter, 'A'
	rcall lcd_write_caracter
	ldi lcd_caracter, 'O'
	rcall lcd_write_caracter
	ldi lcd_caracter, '.'
	rcall lcd_write_caracter
	ldi lcd_caracter, '.'
	rcall lcd_write_caracter
	ldi lcd_caracter, '.'
	rcall lcd_write_caracter

	ldi transmit_caracter,10
	rcall usart_transmit
	ldi transmit_caracter,13
	rcall usart_transmit
	ldi transmit_caracter,'I'	; carrega o caracter
	rcall usart_transmit	;transmite o caracter	
	ldi transmit_caracter,'N'
	rcall usart_transmit
	ldi transmit_caracter,'I'
	rcall usart_transmit
	ldi transmit_caracter,'C'
	rcall usart_transmit
	ldi transmit_caracter,'I'
	rcall usart_transmit
	ldi transmit_caracter,'O'
	rcall usart_transmit
	ldi transmit_caracter,' '
	rcall usart_transmit
	ldi transmit_caracter,'D'
	rcall usart_transmit
	ldi transmit_caracter,'E'
	rcall usart_transmit
	ldi transmit_caracter,' '
	rcall usart_transmit
	ldi transmit_caracter,'O'
	rcall usart_transmit
	ldi transmit_caracter,'P'
	rcall usart_transmit
	ldi transmit_caracter,'E'
	rcall usart_transmit
	ldi transmit_caracter,'R'
	rcall usart_transmit
	ldi transmit_caracter,'A'
	rcall usart_transmit
	ldi transmit_caracter,'C'
	rcall usart_transmit
	ldi transmit_caracter,'A'
	rcall usart_transmit
	ldi transmit_caracter,'O'
	rcall usart_transmit
	ldi transmit_caracter,10
	rcall usart_transmit
	ldi transmit_caracter,13
	rcall usart_transmit
	ldi transmit_caracter,10
	rcall usart_transmit
	ldi transmit_caracter,13
	rcall usart_transmit
	ldi transmit_caracter,10
	rcall usart_transmit
	ldi transmit_caracter,13
	rcall usart_transmit


	mov timer, TTORRA;
	mov valor_PWM, TTORRA
	ldi aux, 200
	ADD valor_PWM, aux

	ldi transmit_caracter,10
	rcall usart_transmit
	ldi transmit_caracter,13
	rcall usart_transmit
	ldi transmit_caracter,'T'	; carrega o caracter
	rcall usart_transmit	;transmite o caracter	
	ldi transmit_caracter,'O'
	rcall usart_transmit
	ldi transmit_caracter,'R'
	rcall usart_transmit
	ldi transmit_caracter,'R'
	rcall usart_transmit
	ldi transmit_caracter,'A'
	rcall usart_transmit
	ldi transmit_caracter,'N'
	rcall usart_transmit
	ldi transmit_caracter,'D'
	rcall usart_transmit
	ldi transmit_caracter,'O'
	rcall usart_transmit
	ldi transmit_caracter,10
	rcall usart_transmit
	ldi transmit_caracter,13
	rcall usart_transmit
	ldi transmit_caracter,10
	rcall usart_transmit
	ldi transmit_caracter,13
	rcall usart_transmit
	ldi transmit_caracter,10
	rcall usart_transmit
	ldi transmit_caracter,13
	rcall usart_transmit
	sbi PORTB, 5

TORRANDO:
	
	rcall imprime_TORRANDO 

	sbis PINC, 3
	rjmp EMERGENCIA

	tst timer
	breq SET_MOENDO
	rjmp TORRANDO

SET_MOENDO:
	cbi PORTB, 5
	mov timer, TMOAR;
	ldi transmit_caracter,10
	rcall usart_transmit
	ldi transmit_caracter,13
	rcall usart_transmit
	ldi transmit_caracter,'M'	; carrega o caracter
	rcall usart_transmit	;transmite o caracter	
	ldi transmit_caracter,'O'
	rcall usart_transmit
	ldi transmit_caracter,'E'
	rcall usart_transmit
	ldi transmit_caracter,'N'
	rcall usart_transmit
	ldi transmit_caracter,'D'
	rcall usart_transmit
	ldi transmit_caracter,'O'
	rcall usart_transmit
	ldi transmit_caracter,10
	rcall usart_transmit
	ldi transmit_caracter,13
	rcall usart_transmit
	ldi transmit_caracter,10
	rcall usart_transmit
	ldi transmit_caracter,13
	rcall usart_transmit
	ldi transmit_caracter,10
	rcall usart_transmit
	ldi transmit_caracter,13
	rcall usart_transmit
	sbi PORTB, 6

MOENDO:
	
	rcall imprime_MOENDO 

	sbis PINC, 3
	rjmp EMERGENCIA

	tst timer
	breq SET_ESQUENTANDO
	rjmp MOENDO

SET_ESQUENTANDO:
	cbi PORTB, 6
	mov timer, TESQUENTAR
	ldi transmit_caracter,10
	rcall usart_transmit
	ldi transmit_caracter,13
	rcall usart_transmit
	ldi transmit_caracter,'E'	; carrega o caracter
	rcall usart_transmit	;transmite o caracter	
	ldi transmit_caracter,'S'
	rcall usart_transmit
	ldi transmit_caracter,'Q'
	rcall usart_transmit
	ldi transmit_caracter,'U'
	rcall usart_transmit
	ldi transmit_caracter,'E'
	rcall usart_transmit
	ldi transmit_caracter,'N'
	rcall usart_transmit
	ldi transmit_caracter,'T'
	rcall usart_transmit
	ldi transmit_caracter,'A'
	rcall usart_transmit
	ldi transmit_caracter,'N'
	rcall usart_transmit
	ldi transmit_caracter,'D'
	rcall usart_transmit
	ldi transmit_caracter,'O'
	rcall usart_transmit
	ldi transmit_caracter,10
	rcall usart_transmit
	ldi transmit_caracter,13
	rcall usart_transmit
	ldi transmit_caracter,10
	rcall usart_transmit
	ldi transmit_caracter,13
	rcall usart_transmit
	ldi transmit_caracter,10
	rcall usart_transmit
	ldi transmit_caracter,13
	rcall usart_transmit

ESQUENTANDO:
	rcall Imprime_ESQUENTANDO

	sbis PINC, 3
	rjmp EMERGENCIA
	tst timer
	breq SET_INFUSAO
	rjmp ESQUENTANDO

SET_INFUSAO:
	mov timer, TINFUSAO
	ldi transmit_caracter,10
	rcall usart_transmit
	ldi transmit_caracter,13
	rcall usart_transmit
	ldi transmit_caracter,'E'	; carrega o caracter
	rcall usart_transmit	;transmite o caracter	
	ldi transmit_caracter,'M'
	rcall usart_transmit
	ldi transmit_caracter,' '
	rcall usart_transmit
	ldi transmit_caracter,'I'
	rcall usart_transmit
	ldi transmit_caracter,'N'
	rcall usart_transmit
	ldi transmit_caracter,'F'
	rcall usart_transmit
	ldi transmit_caracter,'U'
	rcall usart_transmit
	ldi transmit_caracter,'S'
	rcall usart_transmit
	ldi transmit_caracter,'A'
	rcall usart_transmit
	ldi transmit_caracter,'O'
	rcall usart_transmit
	ldi transmit_caracter,10
	rcall usart_transmit
	ldi transmit_caracter,13
	rcall usart_transmit
	ldi transmit_caracter,10
	rcall usart_transmit
	ldi transmit_caracter,13
	rcall usart_transmit
	ldi transmit_caracter,10
	rcall usart_transmit
	ldi transmit_caracter,13
	rcall usart_transmit
   
INFUSAO:
	rcall Imprime_INFUSAO
	sbis PINC, 3
	rjmp EMERGENCIA
	tst timer
	breq SET_DESPEJANDO
	rjmp INFUSAO

SET_DESPEJANDO:
	mov timer, TDESPEJAR
	ldi transmit_caracter,10
	rcall usart_transmit
	ldi transmit_caracter,13
	rcall usart_transmit
	ldi transmit_caracter,'D'	; carrega o caracter
	rcall usart_transmit	;transmite o caracter	
	ldi transmit_caracter,'E'
	rcall usart_transmit
	ldi transmit_caracter,'S'
	rcall usart_transmit
	ldi transmit_caracter,'P'
	rcall usart_transmit
	ldi transmit_caracter,'E'
	rcall usart_transmit
	ldi transmit_caracter,'J'
	rcall usart_transmit
	ldi transmit_caracter,'A'
	rcall usart_transmit
	ldi transmit_caracter,'N'
	rcall usart_transmit
	ldi transmit_caracter,'D'
	rcall usart_transmit
	ldi transmit_caracter,'O'
	rcall usart_transmit
	ldi transmit_caracter,10
	rcall usart_transmit
	ldi transmit_caracter,13
	rcall usart_transmit
	ldi transmit_caracter,10
	rcall usart_transmit
	ldi transmit_caracter,13
	rcall usart_transmit
	ldi transmit_caracter,10
	rcall usart_transmit
	ldi transmit_caracter,13
	rcall usart_transmit

DESPEJANDO:
	rcall imprime_DESPEJANDO
	sbis PINC, 3
	rjmp EMERGENCIA
	tst timer
	breq SET_BATENDO
	rjmp DESPEJANDO

SET_BATENDO:
	mov timer, TBATER 
	ldi transmit_caracter,10
	rcall usart_transmit
	ldi transmit_caracter,13
	rcall usart_transmit
	ldi transmit_caracter,'B'	; carrega o caracter
	rcall usart_transmit	;transmite o caracter	
	ldi transmit_caracter,'A'
	rcall usart_transmit
	ldi transmit_caracter,'T'
	rcall usart_transmit
	ldi transmit_caracter,'E'
	rcall usart_transmit
	ldi transmit_caracter,'N'
	rcall usart_transmit
	ldi transmit_caracter,'D'
	rcall usart_transmit
	ldi transmit_caracter,'O'
	rcall usart_transmit
	ldi transmit_caracter,' '
	rcall usart_transmit
	ldi transmit_caracter,'L'
	rcall usart_transmit
	ldi transmit_caracter,'E'
	rcall usart_transmit
	ldi transmit_caracter,'I'
	rcall usart_transmit
	ldi transmit_caracter,'T'
	rcall usart_transmit
	ldi transmit_caracter,'E'
	rcall usart_transmit
	ldi transmit_caracter,10
	rcall usart_transmit
	ldi transmit_caracter,13
	rcall usart_transmit
	ldi transmit_caracter,10
	rcall usart_transmit
	ldi transmit_caracter,13
	rcall usart_transmit
	ldi transmit_caracter,10
	rcall usart_transmit
	ldi transmit_caracter,13
	rcall usart_transmit

BATENDO:
	rcall imprime_BATENDO
	sbis PINC, 3
	rjmp EMERGENCIA
	tst timer
	breq SET_FIMREINICIO
	rjmp BATENDO

SET_FIMREINICIO:
	sbi PORTB, 4
	ldi aux, 3
	mov timer, aux
	ldi transmit_caracter,10
	rcall usart_transmit
	ldi transmit_caracter,13
	rcall usart_transmit
	ldi transmit_caracter,'F'	; carrega o caracter
	rcall usart_transmit	;transmite o caracter	
	ldi transmit_caracter,'I'
	rcall usart_transmit
	ldi transmit_caracter,'M'
	rcall usart_transmit
	ldi transmit_caracter,' '
	rcall usart_transmit
	ldi transmit_caracter,10
	rcall usart_transmit
	ldi transmit_caracter,13
	rcall usart_transmit
	    ldi delay_time,1 
	rcall delay_seconds
	cbi PORTB, 4
	

FIMREINICIO:
	ldi aux, 0
	mov TTORRA, aux
	mov TMOAR, aux
	mov TESQUENTAR, aux 
	mov TINFUSAO, aux
	mov TDESPEJAR, aux
	mov TBATER, aux
	rcall desliga_pwm_pb3

	rcall imprime_FIMREINICIO
	tst timer
	rjmp main
	rjmp FIMREINICIO
	

mensagem_TMOAR:
	rcall lcd_clear
	ldi lcd_col, 0
	rcall lcd_lin0_col
	ldi lcd_caracter, 'T'
	rcall lcd_write_caracter
	ldi lcd_caracter, 'E'
	rcall lcd_write_caracter
	ldi lcd_caracter, 'M'
	rcall lcd_write_caracter
	ldi lcd_caracter, 'P'
	rcall lcd_write_caracter
	ldi lcd_caracter, 'O'
	rcall lcd_write_caracter
	ldi lcd_caracter, ' '
	rcall lcd_write_caracter
	ldi lcd_caracter, 'M'
	rcall lcd_write_caracter
	ldi lcd_caracter, 'O'
	rcall lcd_write_caracter
	ldi lcd_caracter, 'A'
	rcall lcd_write_caracter
	ldi lcd_caracter, 'G'
	rcall lcd_write_caracter
	ldi lcd_caracter, 'E'
	rcall lcd_write_caracter
	ldi lcd_caracter, 'M'
	rcall lcd_write_caracter
	ldi lcd_caracter, ' '
	rcall lcd_write_caracter
  Ret


mensagem_TESQUENTAR:
	rcall lcd_clear
	ldi lcd_col, 0
	rcall lcd_lin0_col
	ldi lcd_caracter, 'E'
	rcall lcd_write_caracter
	ldi lcd_caracter, 'S'
	rcall lcd_write_caracter
	ldi lcd_caracter, 'Q'
	rcall lcd_write_caracter
	ldi lcd_caracter, 'U'
	rcall lcd_write_caracter
	ldi lcd_caracter, 'E'
	rcall lcd_write_caracter
	ldi lcd_caracter, 'N'
	rcall lcd_write_caracter
	ldi lcd_caracter, 'T'
	rcall lcd_write_caracter
	ldi lcd_caracter, 'A'
	rcall lcd_write_caracter
	ldi lcd_caracter, 'R'
	rcall lcd_write_caracter
	ldi lcd_caracter, ' '
	rcall lcd_write_caracter
  Ret

mensagem_TINFUSAO:
	rcall lcd_clear
	ldi lcd_col, 0
	rcall lcd_lin0_col
	ldi lcd_caracter, 'I'
	rcall lcd_write_caracter
	ldi lcd_caracter, 'N'
	rcall lcd_write_caracter
	ldi lcd_caracter, 'F'
	rcall lcd_write_caracter
	ldi lcd_caracter, 'U'
	rcall lcd_write_caracter
	ldi lcd_caracter, 'S'
	rcall lcd_write_caracter
	ldi lcd_caracter, 'A'
	rcall lcd_write_caracter
	ldi lcd_caracter, 'O'
	rcall lcd_write_caracter
	Ret

	mensagem_TDESPEJAR:
	rcall lcd_clear
	ldi lcd_col, 0
	rcall lcd_lin0_col
	ldi lcd_caracter, 'D'
	rcall lcd_write_caracter
	ldi lcd_caracter, 'E'
	rcall lcd_write_caracter
	ldi lcd_caracter, 'S'
	rcall lcd_write_caracter
	ldi lcd_caracter, 'P'
	rcall lcd_write_caracter
	ldi lcd_caracter, 'E'
	rcall lcd_write_caracter
	ldi lcd_caracter, 'J'
	rcall lcd_write_caracter
	ldi lcd_caracter, 'A'
	rcall lcd_write_caracter
	ldi lcd_caracter, 'R'
	rcall lcd_write_caracter
	ret

	mensagem_TBATER:
	rcall lcd_clear
	ldi lcd_col, 0
	rcall lcd_lin0_col
	ldi lcd_caracter, 'B'
	rcall lcd_write_caracter
	ldi lcd_caracter, 'A'
	rcall lcd_write_caracter
	ldi lcd_caracter, 'T'
	rcall lcd_write_caracter
	ldi lcd_caracter, 'E'
	rcall lcd_write_caracter
	ldi lcd_caracter, 'R'
	rcall lcd_write_caracter
	ldi lcd_caracter, ' '
	rcall lcd_write_caracter
	ldi lcd_caracter, 'L'
	rcall lcd_write_caracter
	ldi lcd_caracter, 'E'
	rcall lcd_write_caracter
	ldi lcd_caracter, 'I'
	rcall lcd_write_caracter
	ldi lcd_caracter, 'T'
	rcall lcd_write_caracter
	ldi lcd_caracter, 'E'
	rcall lcd_write_caracter
	ret

		imprime_TORRANDO:
	ldi lcd_col, 0
	rcall lcd_lin1_col
	ldi lcd_caracter, 'T'
	rcall lcd_write_caracter
	ldi lcd_caracter, 'O'
	rcall lcd_write_caracter
	ldi lcd_caracter, 'R'
	rcall lcd_write_caracter
	ldi lcd_caracter, 'R'
	rcall lcd_write_caracter
	ldi lcd_caracter, 'R'
	rcall lcd_write_caracter
	ldi lcd_caracter, 'A'
	rcall lcd_write_caracter
	ldi lcd_caracter, 'N'
	rcall lcd_write_caracter
	ldi lcd_caracter, 'D'
	rcall lcd_write_caracter
	ldi lcd_caracter, 'O'
	rcall lcd_write_caracter
	Ret

		imprime_MOENDO:
	ldi lcd_col, 0
	rcall lcd_lin1_col
	ldi lcd_caracter, 'M'
	rcall lcd_write_caracter
	ldi lcd_caracter, 'O'
	rcall lcd_write_caracter
	ldi lcd_caracter, 'E'
	rcall lcd_write_caracter
	ldi lcd_caracter, 'N'
	rcall lcd_write_caracter
	ldi lcd_caracter, 'D'
	rcall lcd_write_caracter
	ldi lcd_caracter, 'O'
	rcall lcd_write_caracter
	ldi lcd_caracter, ' '
	rcall lcd_write_caracter
	ldi lcd_caracter, ' '
	rcall lcd_write_caracter
	ldi lcd_caracter, ' '
	rcall lcd_write_caracter
	ret

	Imprime_ESQUENTANDO:
	ldi lcd_col, 0
	rcall lcd_lin1_col
	ldi lcd_caracter, 'E'
	rcall lcd_write_caracter
	ldi lcd_caracter, 'S'
	rcall lcd_write_caracter
	ldi lcd_caracter, 'Q'
	rcall lcd_write_caracter
	ldi lcd_caracter, 'U'
	rcall lcd_write_caracter
	ldi lcd_caracter, 'E'
	rcall lcd_write_caracter
	ldi lcd_caracter, 'N'
	rcall lcd_write_caracter
	ldi lcd_caracter, 'T'
	rcall lcd_write_caracter
	ldi lcd_caracter, 'A'
	rcall lcd_write_caracter
	ldi lcd_caracter, 'N'
	rcall lcd_write_caracter
	ldi lcd_caracter, 'D'
	rcall lcd_write_caracter
	ldi lcd_caracter, 'O'
	rcall lcd_write_caracter
	ret

	Imprime_INFUSAO:
	ldi lcd_col, 0
	rcall lcd_lin1_col
	ldi lcd_caracter, 'E'
	rcall lcd_write_caracter
	ldi lcd_caracter, 'M'
	rcall lcd_write_caracter
	ldi lcd_caracter, ' '
	rcall lcd_write_caracter
	ldi lcd_caracter, 'I'
	rcall lcd_write_caracter
	ldi lcd_caracter, 'N'
	rcall lcd_write_caracter
	ldi lcd_caracter, 'F'
	rcall lcd_write_caracter
	ldi lcd_caracter, 'U'
	rcall lcd_write_caracter
	ldi lcd_caracter, 'S'
	rcall lcd_write_caracter
	ldi lcd_caracter, 'A'
	rcall lcd_write_caracter
	ldi lcd_caracter, 'O'
	rcall lcd_write_caracter
	ldi lcd_caracter, ' '
	rcall lcd_write_caracter
	ldi lcd_caracter, ' '
	rcall lcd_write_caracter
	ret

	Imprime_PESO:
	ldi lcd_col, 0
	rcall lcd_lin0_col
	ldi lcd_caracter, 'P'
	rcall lcd_write_caracter
	ldi lcd_caracter, 'E'
	rcall lcd_write_caracter
	ldi lcd_caracter, 'S'
	rcall lcd_write_caracter
	ldi lcd_caracter, 'O'
	rcall lcd_write_caracter
	ldi lcd_caracter, ' '
	rcall lcd_write_caracter
	ldi lcd_caracter, 'D'
	rcall lcd_write_caracter
	ldi lcd_caracter, 'E'
	rcall lcd_write_caracter
	ldi lcd_caracter, ' '
	rcall lcd_write_caracter
	ldi lcd_caracter, 'C'
	rcall lcd_write_caracter
	ldi lcd_caracter, 'A'
	rcall lcd_write_caracter
	ldi lcd_caracter, 'F'
	rcall lcd_write_caracter
	ldi lcd_caracter, 'E'
	rcall lcd_write_caracter
	ldi lcd_caracter, ':'
	rcall lcd_write_caracter
	ret


	imprime_DESPEJANDO:
	ldi lcd_col, 0
	rcall lcd_lin1_col
	ldi lcd_caracter, 'D'
	rcall lcd_write_caracter
	ldi lcd_caracter, 'E'
	rcall lcd_write_caracter
	ldi lcd_caracter, 'S'
	rcall lcd_write_caracter
	ldi lcd_caracter, 'P'
	rcall lcd_write_caracter
	ldi lcd_caracter, 'E'
	rcall lcd_write_caracter
	ldi lcd_caracter, 'J'
	rcall lcd_write_caracter
	ldi lcd_caracter, 'A'
	rcall lcd_write_caracter
	ldi lcd_caracter, 'N'
	rcall lcd_write_caracter
	ldi lcd_caracter, 'D'
	rcall lcd_write_caracter
	ldi lcd_caracter, 'O'
	rcall lcd_write_caracter
	ret

imprime_BATENDO:
	ldi lcd_col, 0
	rcall lcd_lin1_col
	ldi lcd_caracter, 'B'
	rcall lcd_write_caracter
	ldi lcd_caracter, 'A'
	rcall lcd_write_caracter
	ldi lcd_caracter, 'T'
	rcall lcd_write_caracter
	ldi lcd_caracter, 'E'
	rcall lcd_write_caracter
	ldi lcd_caracter, 'N'
	rcall lcd_write_caracter
	ldi lcd_caracter, 'D'
	rcall lcd_write_caracter
	ldi lcd_caracter, 'O'
	rcall lcd_write_caracter
	ldi lcd_caracter, ' '
	rcall lcd_write_caracter
	ldi lcd_caracter, 'L'
	rcall lcd_write_caracter
	ldi lcd_caracter, 'E'
	rcall lcd_write_caracter
	ldi lcd_caracter, 'I'
	rcall lcd_write_caracter
	ldi lcd_caracter, 'T'
	rcall lcd_write_caracter
	ldi lcd_caracter, 'E'
	rcall lcd_write_caracter
	ret

imprime_FIMREINICIO:
	rcall lcd_clear
	ldi lcd_col, 0
	rcall lcd_lin0_col
	ldi lcd_caracter, 'F'
	rcall lcd_write_caracter
	ldi lcd_caracter, 'I'
	rcall lcd_write_caracter
	ldi lcd_caracter, 'M'
	rcall lcd_write_caracter
	ldi lcd_caracter, '!'
	rcall lcd_write_caracter
	ldi delay_time,2  
	rcall delay_seconds 
	rcall lcd_clear
	ldi lcd_col, 0
	rcall lcd_lin1_col
	ldi lcd_caracter, 'R'
	rcall lcd_write_caracter
	ldi lcd_caracter, 'E'
	rcall lcd_write_caracter
	ldi lcd_caracter, 'I'
	rcall lcd_write_caracter
	ldi lcd_caracter, 'N'
	rcall lcd_write_caracter
	ldi lcd_caracter, 'I'
	rcall lcd_write_caracter
	ldi lcd_caracter, 'C'
	rcall lcd_write_caracter
	ldi lcd_caracter, 'I'
	rcall lcd_write_caracter
	ldi lcd_caracter, 'A'
	rcall lcd_write_caracter
	ldi lcd_caracter, 'N'
	rcall lcd_write_caracter
	ldi lcd_caracter, 'D'
	rcall lcd_write_caracter
	ldi lcd_caracter, 'O'
	rcall lcd_write_caracter
	ldi lcd_caracter, '.'
	rcall lcd_write_caracter
	ldi lcd_caracter, '.'
	rcall lcd_write_caracter

  ldi delay_time,2  
	rcall delay_seconds
	rcall lcd_clear 
	ret


Imprime_EMERGENCIA:
	rcall lcd_clear
	ldi lcd_col, 0
	rcall lcd_lin0_col
	ldi lcd_caracter, 'E'
	rcall lcd_write_caracter
	ldi lcd_caracter, 'M'
	rcall lcd_write_caracter
	ldi lcd_caracter, 'E'
	rcall lcd_write_caracter
	ldi lcd_caracter, 'R'
	rcall lcd_write_caracter
	ldi lcd_caracter, 'G'
	rcall lcd_write_caracter
	ldi lcd_caracter, 'E'
	rcall lcd_write_caracter
	ldi lcd_caracter, 'N'
	rcall lcd_write_caracter
	ldi lcd_caracter, 'C'
	rcall lcd_write_caracter
	ldi lcd_caracter, 'I'
	rcall lcd_write_caracter
	ldi lcd_caracter, 'A'
	rcall lcd_write_caracter
	ldi delay_time,2  
	rcall delay_seconds 
	rcall lcd_clear
	ldi lcd_col, 0
	rcall lcd_lin1_col
	ldi lcd_caracter, 'R'
	rcall lcd_write_caracter
	ldi lcd_caracter, 'E'
	rcall lcd_write_caracter
	ldi lcd_caracter, 'I'
	rcall lcd_write_caracter
	ldi lcd_caracter, 'N'
	rcall lcd_write_caracter
	ldi lcd_caracter, 'I'
	rcall lcd_write_caracter
	ldi lcd_caracter, 'C'
	rcall lcd_write_caracter
	ldi lcd_caracter, 'I'
	rcall lcd_write_caracter
	ldi lcd_caracter, 'A'
	rcall lcd_write_caracter
	ldi lcd_caracter, 'N'
	rcall lcd_write_caracter
	ldi lcd_caracter, 'D'
	rcall lcd_write_caracter
	ldi lcd_caracter, 'O'
	rcall lcd_write_caracter
	ldi lcd_caracter, '.'
	rcall lcd_write_caracter
	ldi lcd_caracter, '.'
	rcall lcd_write_caracter

  ldi delay_time,2  
	rcall delay_seconds
	rcall lcd_clear 
	
	rjmp Comeco

EMERGENCIA:
rcall Imprime_EMERGENCIA
rjmp main

	




